<?php
  header('Content-type: text/javascript; charset=utf-8');
  sleep(2);
?>
if(typeof console!=='undefined'){
    console.log && console.log('i am wake up');
}
